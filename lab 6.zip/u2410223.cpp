#include <iostream>
#include "hdr.h"
using namespace std;
int main() {
	Result Asliddin(123, "Asliddin", "Socie", 37, 85, 90, 78);
	Asliddin.Display();
	cout << endl;
	Result Behruz(123, "Behruz", "Socie", 10, 88, 91, 60);
	Behruz.Display();
	return 0;
}